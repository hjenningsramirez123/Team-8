﻿

    private void Update()
    {
        if(Health <= 0)
        {
            Destroy(gameObject);
        }
    }
